//Hide Warning
//Show Warning Slowly
$(".warning").hide().show("slow");